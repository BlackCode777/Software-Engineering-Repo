package com.blackcode.arch_soft_main_constructor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArchSoftMainConstructorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArchSoftMainConstructorApplication.class, args);
	}

}
