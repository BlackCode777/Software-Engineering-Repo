package com.blackcode.arch_soft_main_constructor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArchSoftMainConstructorApplicationTests {

	@Test
	void contextLoads() {
	}

}
